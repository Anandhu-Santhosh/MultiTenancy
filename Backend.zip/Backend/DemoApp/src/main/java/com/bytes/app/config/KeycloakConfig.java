package com.bytes.app.config;

import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.KeycloakBuilder;
import org.keycloak.admin.client.resource.RealmResource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class KeycloakConfig {

	@Value("${keycloak.admin.username}")
	private String username;

	@Value("${keycloak.admin.realm}")
	private String realm;

	@Value("${keycloak.admin.password}")
	private String password;

	@Value("${keycloak.admin.clientId}")
	private String clientId;

	@Bean
	Keycloak keycloakAdminClient() {
		Keycloak keycloak = KeycloakBuilder.builder().serverUrl("http://localhost:8080").realm(realm).clientId(clientId)
				.username(username).password(password)
				.build();
		return keycloak;

	}

	public RealmResource getRealm() {
		return keycloakAdminClient().realm(realm);
	}
}
