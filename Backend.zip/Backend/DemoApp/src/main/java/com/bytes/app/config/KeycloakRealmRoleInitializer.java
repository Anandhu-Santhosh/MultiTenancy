//package com.bytes.app.config;
//
//import java.util.List;
//
//import org.keycloak.admin.client.Keycloak;
//import org.keycloak.admin.client.KeycloakBuilder;
//import org.keycloak.representations.idm.RoleRepresentation;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.boot.ApplicationArguments;
//import org.springframework.boot.ApplicationRunner;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class KeycloakRealmRoleInitializer implements ApplicationRunner {
//
//    @Value("${keycloak.admin.realm}")
//    private String keycloakRealm;
//
//    @Value("${keycloak.admin.serverUrl}")
//    private String keycloakServerUrl;
//
//    @Value("${keycloak.admin.username}")
//    private String keycloakAdminUsername;
//
//    @Value("${keycloak.admin.password}")
//    private String keycloakAdminPassword;
//
//    @Value("${keycloak.roles-to-create}")
//    private List<String> roleNames;
//    
//	@Value("${keycloak.admin.clientId}")
//	private String clientId;
//
//    @Override
//    public void run(ApplicationArguments args) {
//        Keycloak keycloak = KeycloakBuilder.builder()
//                .serverUrl(keycloakServerUrl)
//                .realm(keycloakRealm)
//                .username(keycloakAdminUsername)
//                .password(keycloakAdminPassword)
//                .clientId(clientId)
//                .build();
//
//        for (String roleName : roleNames) {
//            // Check if the role already exists
//            if (!roleExists(keycloak, keycloakRealm, roleName)) {
//                // If the role doesn't exist, create it
//                createRole(keycloak, keycloakRealm, roleName);
//            }
//        }
//
//        keycloak.close();
//    }
//
//    private boolean roleExists(Keycloak keycloak, String realmName, String roleName) {
//        List<RoleRepresentation> roles = keycloak.realm(realmName).roles().list();
//        return roles.stream().anyMatch(role -> role.getName().equals(roleName));
//    }
//
//    private void createRole(Keycloak keycloak, String realmName, String roleName) {
//        RoleRepresentation roleRepresentation = new RoleRepresentation();
//        roleRepresentation.setName(roleName);
//
//        // You can customize the role representation as needed (e.g., set description, attributes)
//
//        keycloak.realm(realmName).roles().create(roleRepresentation);
//
//    }
//}
