package com.bytes.app.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bytes.app.model.KeycloakUserBody;
import com.bytes.app.model.Tenant;
import com.bytes.app.service.MasterService;

@RestController
@RequestMapping("/api/v1")
public class MasterControl {
	
	@Autowired
	MasterService masterService;

	@PostMapping("/createTenant")
//	@PreAuthorize("hasRole('MasterAdmin')")
	public Map<String, Object> createTenant(@RequestBody Tenant tenant) {
		String status=masterService.createTenant(tenant);
		Map<String, Object> response = new HashMap<>();
		response.put("status", status);
		return response;
	}

	@PostMapping("/createAdmin")
//	@PreAuthorize("hasRole('MasterAdmin')")
	public Map<String, Object> createAdmin(@RequestBody KeycloakUserBody keycloakUser) {
		String status=masterService.createAdmin(keycloakUser);
		Map<String, Object> response = new HashMap<>();
		response.put("status", status);
		return response;
	}

	@GetMapping("/createRole/{role}")
//	@PreAuthorize("hasRole('MasterAdmin')")
	public Map<String, Object> createRealmRole(@PathVariable String role) {
		String status=masterService.createRealmRole(role);
		Map<String, Object> response = new HashMap<>();
		response.put("status", status);
		return response;
	}

	@GetMapping("/findTenants")
//	@PreAuthorize("hasRole('MasterAdmin')")
	public List<Tenant> findTenants() {
		return masterService.findTenants();
	}

	@PostMapping("/addNewSubTenant")
//	@PreAuthorize("hasRole('MasterAdmin')")
	public Map<String, Object> addNewSubTenant(@RequestBody Tenant tenant) {
		String status=masterService.addNewSubTenant(tenant);
		Map<String, Object> response = new HashMap<>();
		response.put("status", status);
		return response;
	}

	@PostMapping("/changeDepartmentToTenant/{id}")
//	@PreAuthorize("hasRole('MasterAdmin')")
	public void changeDepartmentToTenant(@PathVariable String id) {
		masterService.changeDepartmentToTenant(id);
	}

}
