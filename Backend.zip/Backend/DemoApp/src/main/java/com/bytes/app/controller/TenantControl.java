package com.bytes.app.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bytes.app.model.Departments;
import com.bytes.app.model.KeycloakUserBody;
import com.bytes.app.model.Roles;
import com.bytes.app.model.Users;
import com.bytes.app.service.TenantService;

@RestController
@RequestMapping("/api/v2")
public class TenantControl {
	
	@Autowired
	TenantService tenantService;
	
	@PostMapping("/addUser")
	public Map<String, Object> addUser(@RequestBody KeycloakUserBody keycloakUserBody) {
		String status=tenantService.createUser(keycloakUserBody);
		Map<String, Object> response = new HashMap<>();
		response.put("status", status);
		return response;
	}
	
	@GetMapping("/addRole/{role}/{tenant}")
	public String addRole(@PathVariable String role,@PathVariable String tenant) {
		return tenantService.createRoles(role, tenant);
	}
	
	@GetMapping("/getAllRoles")
	public List<Roles> getAllRoles() {
		return tenantService.getAllRoles();
	}
	
	@GetMapping("/getAllUsers")
	public List<Users> getAllUsers() {
		return tenantService.getAllUsers();
	}
	
	@GetMapping("/addDepartment/{parentId}/{childName}/{tenant}")
	public void addDepartment(@PathVariable String parentId,@PathVariable String childName,@PathVariable String tenant) {
		tenantService.createDepartment(parentId, childName,tenant);
	}
	
	@GetMapping("/getDepartments")
	public List<Departments> getDepartments(){
		return tenantService.getDepartments();
	}
	
	@GetMapping("/updateRole/{id}/{role}")
	public void updateRole(@PathVariable String id,@PathVariable String role) {
		tenantService.updateUserRole(id, role);
	}

}
