package com.bytes.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bytes.app.model.Task;
import com.bytes.app.model.Users;
import com.bytes.app.service.UserService;

@RestController
@RequestMapping("/api/v3")
public class UserControl {
	
	@Autowired
	UserService tenantUserService;
	
	@GetMapping("/viewUser")
	public Users viewUser() {
		return tenantUserService.viewUser();
	}
	
	@GetMapping("/viewSubordinates")
	public List<Object> viewSubordinates() {
		return tenantUserService.viewSubordinates();
	}
	
	@PostMapping("/assignTasks/{assigneeId}")
	public void assignTask(@RequestBody Task task,@PathVariable String assigneeId) {
		tenantUserService.assignTask(task, assigneeId);
	}
	
	@GetMapping("/viewTasks")
	public List<Task> viewTasks(){
		return tenantUserService.viewTasks();
	}
	
	@GetMapping("/viewAssignedTasks")
	public List<Task> viewAssignedTasks(){
		return tenantUserService.viewAssignedTasks();
	}
	
	@GetMapping("/updateTask/{id}/{status}")
	public void updateTask(@PathVariable String id,@PathVariable String status) {
		tenantUserService.updateStatus(id, status);
	}

}
