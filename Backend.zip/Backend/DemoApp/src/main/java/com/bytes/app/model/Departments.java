package com.bytes.app.model;

import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.ParamDef;
import org.springframework.security.access.annotation.Secured;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
@Secured("ROLE_USER")
@FilterDef(name = "departmentsFilter", parameters = @ParamDef(name = "tenantId", type = String.class))
@Filter(name = "departmentsFilter", condition = "tenant_id = :tenantId")
public class Departments {
	
	@Id
	String id;
	String name;
	
	@ManyToOne
	Departments department;
	
	@ManyToOne
	Tenant tenant;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Tenant getTenant() {
		return tenant;
	}

	public void setTenant(Tenant tenant) {
		this.tenant = tenant;
	}

	public Departments getDepartment() {
		return department;
	}

	public void setDepartment(Departments department) {
		this.department = department;
	}
	
	
}
