package com.bytes.app.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Task {
	
	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
	String id;
	String name;
	@Column(length = 2000)
	String description;
	String status;
	LocalDate startDate;
	LocalDate endDate;

    @ManyToOne
    @JoinColumn(name = "assigner_user_id")
    private Users assignerUser;

    @ManyToOne
    @JoinColumn(name = "assignee_user_id")
    private Users assigneeUser;
    
	@ManyToOne
	Tenant tenant;


	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Users getAssignerUser() {
		return assignerUser;
	}

	public void setAssignerUser(Users assignerUser) {
		this.assignerUser = assignerUser;
	}

	public Users getAssigneeUser() {
		return assigneeUser;
	}

	public void setAssigneeUser(Users assigneeUser) {
		this.assigneeUser = assigneeUser;
	}

	public Tenant getTenant() {
		return tenant;
	}

	public void setTenant(Tenant tenant) {
		this.tenant = tenant;
	}

}
