package com.bytes.app.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Tenant {
	
	@Id
	String id;
	String name;
	String authenticationService;
	String dbService;
	@ManyToOne
    @JoinColumn(name = "parent_id")
	Tenant tenant;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Tenant getTenant() {
		return tenant;
	}
	public void setTenant(Tenant tenant) {
		this.tenant = tenant;
	}
	public String getAuthenticationService() {
		return authenticationService;
	}
	public void setAuthenticationService(String authenticationService) {
		this.authenticationService = authenticationService;
	}
	public String getDbService() {
		return dbService;
	}
	public void setDbService(String dbService) {
		this.dbService = dbService;
	}
	
}
