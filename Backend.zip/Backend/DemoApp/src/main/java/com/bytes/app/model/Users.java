package com.bytes.app.model;

import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.ParamDef;
import org.springframework.security.access.annotation.Secured;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
@Secured("ROLE_USER")
@FilterDef(name = "userFilter", parameters = @ParamDef(name = "tenantId", type = String.class))
@Filter(name = "userFilter", condition = "tenant_id = :tenantId")
@FilterDef(name = "usernameFilter", parameters = @ParamDef(name = "username", type = String.class))
@Filter(name = "usernameFilter", condition = "username = :username")
public class Users {
	
	@Id
	String id;
	String userName;
	String serviceId;
	
	@ManyToOne
	Tenant tenant;
	
	@ManyToOne
	Roles role;
	
	@ManyToOne
	Departments department;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public Tenant getTenant() {
		return tenant;
	}

	public void setTenant(Tenant tenant) {
		this.tenant = tenant;
	}

	public Roles getRole() {
		return role;
	}

	public void setRole(Roles role) {
		this.role = role;
	}

	public Departments getDepartment() {
		return department;
	}

	public void setDepartment(Departments department) {
		this.department = department;
	}
	
	

}
