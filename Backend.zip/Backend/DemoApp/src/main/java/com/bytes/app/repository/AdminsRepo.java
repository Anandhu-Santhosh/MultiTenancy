package com.bytes.app.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bytes.app.model.Admins;
import com.bytes.app.model.Departments;
import com.bytes.app.model.Tenant;

@Repository
public interface AdminsRepo extends JpaRepository<Admins, String>{

	Admins findByTenant(Tenant findByName);

	Admins findByServiceId(String userId);

//	Admins findById(String userId);


}

