package com.bytes.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bytes.app.model.Departments;
import com.bytes.app.model.Tenant;

@Repository
public interface DepartmentsRepo extends JpaRepository<Departments, String> {

	Departments findByName(String parentName);

	@Query(value="WITH RECURSIVE TenantHierarchy AS\r\n"
			+ "(SELECT *, 1 AS depth\r\n"
			+ "FROM departments\r\n"
			+ "WHERE id = :departmentId\r\n"
			+ "UNION ALL\r\n"
			+ "SELECT r.*,h.depth + 1 AS depth\r\n"
			+ "FROM departments r\r\n"
			+ "INNER JOIN TenantHierarchy h ON r.department_id = h.id\r\n"
			+ " WHERE h.depth < 2\r\n"
			+ ") \r\n"
			+ "SELECT t.id,t.name,t.tenant_id,t.department_id FROM TenantHierarchy t where t.id NOT IN (:departmentId)",nativeQuery = true)
	List<Departments> findSubGroups(@Param("departmentId") String departmentId);

	@Query(value="WITH RECURSIVE dept AS\r\n"
			+ "(SELECT id,name, department_id, 1 AS level\r\n"
			+ "FROM departments\r\n"
			+ "WHERE id = :id\r\n"
			+ "UNION ALL\r\n"
			+ "SELECT t.id,t.name, t.department_id, level+1\r\n"
			+ "FROM departments t \r\n"
			+ "INNER JOIN dept h ON t.department_id = h.id)   \r\n"
			+ "SELECT * FROM dept t ",nativeQuery = true)
	List<Object> findDeptHierarchy(@Param("id") String id);

	Departments findByNameAndTenant(String tenantName, Tenant tenant);


}

