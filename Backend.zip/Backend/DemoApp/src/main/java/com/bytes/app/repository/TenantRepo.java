package com.bytes.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bytes.app.model.Tenant;

@Repository
public interface TenantRepo extends JpaRepository<Tenant, String> {

	Tenant findByName(String name);

//	Tenant findById(String parentId);

	Tenant findByTenant(Tenant tenant);


}
