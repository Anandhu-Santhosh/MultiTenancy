package com.bytes.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bytes.app.model.Users;

@Repository
public interface UsersRepo extends JpaRepository<Users, String> {

//	Users findById(String userId);

	@Query(value="SELECT r.user_name,s.name,t.name as department_name FROM\r\n"
			+ "(Select * from users where department_id in\r\n"
			+ "(\r\n"
			+ "WITH RECURSIVE TenantHierarchy AS\r\n"
			+ "(SELECT id,name,department_id\r\n"
			+ "FROM departments\r\n"
			+ "WHERE id = :userId\r\n"
			+ "UNION ALL\r\n"
			+ "SELECT t.id,t.name, t.department_id\r\n"
			+ "FROM departments t \r\n"
			+ "INNER JOIN TenantHierarchy h ON t.department_id = h.id) \r\n"
			+ "SELECT id FROM TenantHierarchy t \r\n"
			+ "	\r\n"
			+ "WHERE t.department_id IS NOT NULL\r\n"
			+ "AND t.id NOT IN (SELECT department_id FROM TenantHierarchy WHERE department_id IS NOT NULL)))\r\n"
			+ "AS r\r\n"
			+ "INNER JOIN departments t ON t.id=r.department_id\r\n"
			+ "INNER JOIN roles s ON s.id=r.role_id",nativeQuery = true)
	List<Object> findSubordinates(@Param("userId")String userId);

	List<Users> findByDepartmentId(String id);

	Users findByUserName(String userName);

	Users findByServiceId(String id);




}
