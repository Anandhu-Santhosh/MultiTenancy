package com.bytes.app.service;

import com.bytes.app.model.KeycloakUserBody;
import com.bytes.app.model.Roles;

public interface KeycloakService {
	
	public String createGroup(String groupName);
	
	public KeycloakUserBody addKeycloakUser(KeycloakUserBody user);
	
	public KeycloakUserBody addAttributes(KeycloakUserBody user,String key,String value);
	
	public void assignRole(String userId,String roles);

	//If the role is already present, 
	public Roles createRoles(String role);
	
	public String createSubGroup(String parentId,String childName, String tenant);
	
	//need to change group name to group id due to presence of groups with similar names
	public void addUserToGroup(String groupName,String userId,String tenant);
	
	public void updateUserRole(String id,String role);

	void removeUserFromGroup(String deptId, String userId, String tenant);

	public void deleteGroup(String id);

}
