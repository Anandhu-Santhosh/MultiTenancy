package com.bytes.app.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.keycloak.admin.client.CreatedResponseUtil;
import org.keycloak.admin.client.resource.GroupResource;
import org.keycloak.admin.client.resource.GroupsResource;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.RoleResource;
import org.keycloak.admin.client.resource.RolesResource;
import org.keycloak.admin.client.resource.UserResource;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.GroupRepresentation;
import org.keycloak.representations.idm.RoleRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bytes.app.config.KeycloakConfig;
import com.bytes.app.model.KeycloakUserBody;
import com.bytes.app.model.Roles;
import com.bytes.app.model.Users;
import com.bytes.app.repository.DepartmentsRepo;
import com.bytes.app.repository.TenantRepo;
import com.bytes.app.repository.UsersRepo;

import jakarta.ws.rs.core.Response;

@Service
public class KeycloakServiceImpl implements KeycloakService {

	@Autowired
	KeycloakConfig keycloakConfig;

	@Autowired
	TenantRepo tenantRepo;

	@Autowired
	DepartmentsRepo departmentsRepo;

	@Autowired
	UsersRepo usersRepo;

	@Override
	public String createGroup(String groupName) {
		System.out.println("Here");
		RealmResource realmResource = keycloakConfig.getRealm();
		GroupsResource groupsResource = realmResource.groups();
		GroupRepresentation groupRepresentation = new GroupRepresentation();
		groupRepresentation.setName(groupName);
		Response response = groupsResource.add(groupRepresentation);
		String groupId = CreatedResponseUtil.getCreatedId(response);
		String roleToCreate = groupName + "Admin";
		RolesResource rolesResource = realmResource.roles();
		RoleRepresentation roleRepresentation = new RoleRepresentation();
		roleRepresentation.setName(roleToCreate);
		rolesResource.create(roleRepresentation);
		RoleResource roleResource = rolesResource.get(roleToCreate);

		if (roleResource.toRepresentation() == null) {
			System.out.println("Role does not exist: " + roleToCreate);
		} else {
			groupsResource.group(groupId).roles().realmLevel()
					.add(Collections.singletonList(roleResource.toRepresentation()));
		}
		return groupId;
	}

	@Override
	public KeycloakUserBody addKeycloakUser(KeycloakUserBody keycloakUser) {

		List<String> roles = new ArrayList<>(Arrays.asList(keycloakUser.getRole()));
		RealmResource realmResource = keycloakConfig.getRealm();
		System.out.println(realmResource.users().count());
		UserRepresentation user = new UserRepresentation();
		user.setUsername(keycloakUser.getUserName());
		user.setFirstName(keycloakUser.getFirstName());
		user.setLastName(keycloakUser.getLastName());
		user.setEmail(keycloakUser.getEmail());
		user.setEnabled(true);
		user.setRealmRoles(roles);
		System.out.println(user.getUsername() + " " + user.getEmail() + " " + user.getFirstName());
		Response response = realmResource.users().create(user);
		System.out.println(response.getStatus());
		String userId = CreatedResponseUtil.getCreatedId(response);
		keycloakUser.setId(userId);
		setPassword(response, keycloakUser.getPassword());
//		assignRole(userId, keycloakUser.getRole());
//		UserResource userResource = realmResource.users().get(userId);
//		System.out.println(keycloakUser.getTenant());
//		userResource.joinGroup(tenantRepo.findByName(keycloakUser.getTenant()).getId());
		System.out.println("test");
		return keycloakUser;
	}

	public void setPassword(Response response, String password) {
		RealmResource realmResource = keycloakConfig.getRealm();
		CredentialRepresentation passwordCred = new CredentialRepresentation();
		String userId = CreatedResponseUtil.getCreatedId(response);
		System.out.println(userId);
		passwordCred.setTemporary(false);
		passwordCred.setType("password");
		passwordCred.setValue(password);
		UserResource userResource = realmResource.users().get(userId);
		userResource.resetPassword(passwordCred);
		System.out.println("Here2");
	}

	@Override
	public void assignRole(String userId, String roles) {
		RealmResource realmResource = keycloakConfig.getRealm();
		RoleRepresentation role = realmResource.roles().get(roles).toRepresentation();
		realmResource.users().get(userId).roles().realmLevel().add(Arrays.asList(role));
	}

	@Override
	public KeycloakUserBody addAttributes(KeycloakUserBody user, String key, String value) {
		Map<String, List<String>> attributes = Map.of(key, List.of(value));
		RealmResource realmResource = keycloakConfig.getRealm();
		UserResource userResource = realmResource.users().get(user.getId());
		UserRepresentation userRepresentation = userResource.toRepresentation();
		userRepresentation.setAttributes(attributes);
		userResource.update(userRepresentation);
		return user;
	}

	@Override
	public Roles createRoles(String roles) {
		RealmResource realmResource = keycloakConfig.getRealm();
		RoleRepresentation role = new RoleRepresentation();
		role.setName(roles);
		realmResource.roles().create(role);
		RoleRepresentation createdRole = realmResource.roles().get(roles).toRepresentation();
		Roles dbRole=new Roles();
		dbRole.setId(createdRole.getId());
		dbRole.setName(roles);
		return dbRole;
	}

	@Override
	public String createSubGroup(String parentId, String childName, String tenant) {
		RealmResource realmResource = keycloakConfig.getRealm();
//		Departments parent=departmentsRepo.findById(parentId);
//		String parentName;
//		if(parent==null) {
//			parentName=tenantRepo.findById(parentId);
//		}
//		else {
//			parentName=parent.getId();
//		}
//		if (parentName.equals(tenant)) {
//			parentId = tenantRepo.findByName(parentName).getId();
//		} else {
//			parentId = departmentsRepo.findByName(parentName).getId();
//		}
		GroupResource parentGroupResource = realmResource.groups().group(parentId);
		GroupRepresentation subGroupRepresentation = new GroupRepresentation();
		subGroupRepresentation.setName(childName);
		Response response = parentGroupResource.subGroup(subGroupRepresentation);
		String id = CreatedResponseUtil.getCreatedId(response);

		String roleToCreate = tenant + "User";
		RolesResource rolesResource = realmResource.roles();
		RoleRepresentation roleRepresentation = new RoleRepresentation();
		roleRepresentation.setName(roleToCreate);
		RoleResource roleResource = rolesResource.get(roleToCreate);
		realmResource.groups().group(id).roles().realmLevel()
				.add(Collections.singletonList(roleResource.toRepresentation()));
		return id;
	}

	@Override
	public void addUserToGroup(String deptId, String userId, String tenant) {
		RealmResource realmResource = keycloakConfig.getRealm();
		UserResource userResource = realmResource.users().get(userId);
		userResource.joinGroup(deptId);
	}

	@Override
	public void removeUserFromGroup(String deptId, String userId, String tenant) {
		RealmResource realmResource = keycloakConfig.getRealm();
		UserResource userResource = realmResource.users().get(userId);
		userResource.leaveGroup(deptId);
	}

	@Override
	public void updateUserRole(String id, String role) {
		RealmResource realmResource = keycloakConfig.getRealm();
		Users user = usersRepo.findById(id).orElse(null);
		String currentRole = user.getRole().getName();

		RoleRepresentation roleRepresentation = realmResource.roles().get(role).toRepresentation();
		realmResource.users().get(id).roles().realmLevel().add(Arrays.asList(roleRepresentation));
		RoleRepresentation currentRoleRepresentation = realmResource.roles().get(currentRole).toRepresentation();
		realmResource.users().get(id).roles().realmLevel().remove(Arrays.asList(currentRoleRepresentation));
	}

	@Override
	public void deleteGroup(String id) {
		RealmResource realmResource = keycloakConfig.getRealm();
		 GroupsResource groupsResource =realmResource.groups();
         GroupResource groupResource = groupsResource.group(id);
         GroupRepresentation groupRepresentation = groupResource.toRepresentation();
         if (groupRepresentation != null) {
             groupResource.remove();
         } else {
             System.out.println("Group with ID " + id + " not found.");
         }
	}

}
