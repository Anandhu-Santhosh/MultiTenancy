package com.bytes.app.service;

import java.util.List;

import com.bytes.app.model.DeptHierarchy;
import com.bytes.app.model.KeycloakUserBody;
import com.bytes.app.model.Tenant;

public interface MasterService {

	String createTenant(Tenant tenant);

	String createAdmin(KeycloakUserBody keycloakUser);

	List<Tenant> findTenants();
	
	String createRealmRole(String role);

	void changeDepartmentToTenant(String id);
	
	void transferUsers(String id, List<DeptHierarchy> list, String tenantName);

	String addNewSubTenant(Tenant tenant);
	
	//Create new tenants
	
	//Add 1st TenantAdmin to tenant
	
	//View all Tenants
	
	//Add services

}
