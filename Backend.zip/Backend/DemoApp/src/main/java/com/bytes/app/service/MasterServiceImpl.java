package com.bytes.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bytes.app.model.Admins;
import com.bytes.app.model.Departments;
import com.bytes.app.model.DeptHierarchy;
import com.bytes.app.model.KeycloakUserBody;
import com.bytes.app.model.Roles;
import com.bytes.app.model.Tenant;
import com.bytes.app.repository.AdminsRepo;
import com.bytes.app.repository.DepartmentsRepo;
import com.bytes.app.repository.RolesRepo;
import com.bytes.app.repository.TenantRepo;
import com.bytes.app.util.IdGeneration;

@Service
public class MasterServiceImpl implements MasterService {
	
    @Value("${authService}")
    private String authService;

    @Value("${dbService}")
    private String dbService;
	
	@Autowired
	KeycloakService keycloakService;

	@Autowired
	TenantRepo tenantRepo;

	@Autowired
	DepartmentsRepo departmentsRepo;
	
	@Autowired
	AdminsRepo adminsRepo;
	
	@Autowired
	RolesRepo rolesRepo;
	
	@Autowired
	IdGeneration generator;

	@Override
	public String createTenant(Tenant tenant) {
		if (tenantRepo.findByName(tenant.getName()) == null) {
			String tenantId = generator.tenantIdGeneration();
			Roles adminRole=keycloakService.createRoles(tenant.getName() + "Admin");
			Roles userRole=keycloakService.createRoles(tenant.getName() + "User");
			tenant.setId(tenantId);
		    tenant.setAuthenticationService(authService);
		    tenant.setDbService(dbService);
			tenant=tenantRepo.save(tenant);
//			rolesRepo.save(adminRole);
//			rolesRepo.save(userRole);
			String departmentId=generator.departmentsIdGeneration();
			Departments department = new Departments();
			department.setId(departmentId);
			department.setName(tenant.getName());
			department.setDepartment(null);
			department.setTenant(tenant);
			departmentsRepo.save(department);
			return "Success";
		}
		return "Fail";
	}

	@Override
	public String createAdmin(KeycloakUserBody keycloakUser) {
		if (adminsRepo.findByTenant(tenantRepo.findByName(keycloakUser.getTenant())) == null) {
			KeycloakUserBody user = keycloakService.addKeycloakUser(keycloakUser);
			keycloakService.assignRole(user.getId(), user.getTenant()+"Admin");
			keycloakService.addAttributes(keycloakUser, "TenantName", keycloakUser.getTenant());
			keycloakService.addAttributes(keycloakUser, "Tenant", tenantRepo.findByName(keycloakUser.getTenant()).getId());
			Admins admin = new Admins();
			admin.setId(generator.adminIdGeneration());
			admin.setServiceId(user.getId());
			admin.setUserName(user.getUserName());
			admin.setTenant(tenantRepo.findByName(user.getTenant()));
			adminsRepo.save(admin);
			return "Success";
		}
		return "Fail";
	}

	@Override
	public List<Tenant> findTenants() {
		return tenantRepo.findAll();
	}

	@Override
	public String createRealmRole(String role) {
		Roles entity=keycloakService.createRoles(role);
		if(entity==null) {
			return "Fail";
		}else {
			rolesRepo.save(entity);
			return "Success";
		}
	}

	@Override
	public void changeDepartmentToTenant(String id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void transferUsers(String id, List<DeptHierarchy> list, String tenantName) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String addNewSubTenant(Tenant tenant) {
		tenant.setTenant(tenantRepo.findById(tenant.getTenant().getId()).orElse(null));
		return createTenant(tenant);
	}

}
