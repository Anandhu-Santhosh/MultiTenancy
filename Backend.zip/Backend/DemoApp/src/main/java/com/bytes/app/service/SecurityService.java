package com.bytes.app.service;

public interface SecurityService {
	
	void enableFilter(String id);
	
	void enableUserFilter(String id);
	
	void enableDepartmentsFilter(String id);
	
	void disableFilter();
	
	String getTenant();

}
