package com.bytes.app.service;

import java.util.Map;

import org.hibernate.Filter;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Service;

import jakarta.persistence.EntityManager;

@Service
public class SecurityServiceImpl implements SecurityService{
	
	@Autowired
	EntityManager entityManager;
	
	@Override
	public void enableUserFilter(String id) {
		System.out.println(id);
		Filter filter = entityManager.unwrap(Session.class).enableFilter("userFilter");
		filter.setParameter("tenantId", id);
	}

	@Override
	public void enableFilter(String tenantId) {
		System.out.println(tenantId);
		Filter filter = entityManager.unwrap(Session.class).enableFilter("rolesFilter");
		filter.setParameter("tenantId", tenantId);
	}
	
	@Override
	public void enableDepartmentsFilter(String tenantId) {
		System.out.println(tenantId);
		Filter filter = entityManager.unwrap(Session.class).enableFilter("departmentsFilter");
		filter.setParameter("tenantId", tenantId);
	}

	@Override
	public void disableFilter() {
		entityManager.unwrap(Session.class).disableFilter("rolesFilter");
		entityManager.unwrap(Session.class).disableFilter("userFilter");
		entityManager.unwrap(Session.class).disableFilter("departmentsFilter");
	}

	@Override
	public String getTenant() {
		String tenant = null;
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication instanceof JwtAuthenticationToken) {
			JwtAuthenticationToken jwtAuthenticationToken = (JwtAuthenticationToken) authentication;			
			Map<String, Object> attributes = jwtAuthenticationToken.getTokenAttributes();
		    tenant =(String) attributes.get("Tenant");
		}
		return tenant;
	}

}
