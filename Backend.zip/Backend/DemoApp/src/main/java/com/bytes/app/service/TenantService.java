package com.bytes.app.service;

import java.util.List;

import com.bytes.app.model.Departments;
import com.bytes.app.model.KeycloakUserBody;
import com.bytes.app.model.Roles;
import com.bytes.app.model.Users;

public interface TenantService {
	
	String createRoles(String role,String tenant);
	
	String createUser(KeycloakUserBody user);
	
	List<Roles> getAllRoles();

	List<Users> getAllUsers();

	void createDepartment(String parentId,String childName, String tenant);
	
	List<Departments> getDepartments();
	
	void updateUserRole(String id, String role);
	
	List<Object> findDeptHierarchy(String id);

	List<Users> getSubTenantUsers(String id);
	
	//Update user info in both keycloak and database

}

