package com.bytes.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.bytes.app.model.Admins;
import com.bytes.app.model.Departments;
import com.bytes.app.model.KeycloakUserBody;
import com.bytes.app.model.Roles;
import com.bytes.app.model.Users;
import com.bytes.app.repository.AdminsRepo;
import com.bytes.app.repository.DepartmentsRepo;
import com.bytes.app.repository.RolesRepo;
import com.bytes.app.repository.TenantRepo;
import com.bytes.app.repository.UsersRepo;
import com.bytes.app.util.IdGeneration;

@Service
public class TenantServiceImpl implements TenantService {

	@Autowired
	KeycloakService keycloakService;

	@Autowired
	TenantRepo tenantRepo;

	@Autowired
	AdminsRepo adminsRepo;

	@Autowired
	SecurityService securityService;

	@Autowired
	UsersRepo usersRepo;

	@Autowired
	DepartmentsRepo departmentsRepo;

	@Autowired
	RolesRepo rolesRepo;

	@Autowired
	IdGeneration generator;

	@Override
	public String createRoles(String role, String tenant) {
		Roles entity = new Roles();
		entity.setName(role);
		entity.setId(generator.rolesIdGeneration());
		entity.setTenant(tenantRepo.findByName(tenant));
		rolesRepo.save(entity);
		return "Success";

	}

	@Override
	public String createUser(KeycloakUserBody user) {
		if (usersRepo.findByUserName(user.getUserName()) == null) {
			String id = generator.userIdGeneration();
			KeycloakUserBody keycloakUser = keycloakService.addKeycloakUser(user);
			keycloakService.assignRole(keycloakUser.getId(), user.getTenant() + "User");
			keycloakService.addAttributes(keycloakUser, "TenantName", user.getTenant());
			keycloakService.addAttributes(keycloakUser, "Tenant", id);
			Users dbUser = new Users();
			dbUser.setId(id);
			dbUser.setServiceId(keycloakUser.getId());
			dbUser.setUserName(keycloakUser.getUserName());
			dbUser.setRole(rolesRepo.findByName(keycloakUser.getRole()));
			dbUser.setTenant(tenantRepo.findByName(keycloakUser.getTenant()));
			dbUser.setDepartment(departmentsRepo.findById(keycloakUser.getDepartmentId()).orElse(null));
			usersRepo.save(dbUser);
			return "Success";
		}
		return "Fail";
	}

	@Override
	public List<Roles> getAllRoles() {
		securityService.enableFilter(securityService.getTenant());
		List<Roles> roles = rolesRepo.findAll();
		securityService.disableFilter();
		return roles;
	}

	@Override
	public List<Users> getAllUsers() {
		String userId = SecurityContextHolder.getContext().getAuthentication().getName();
		Admins admin = adminsRepo.findByServiceId(userId);
		if (tenantRepo.findByTenant(admin.getTenant()) != null) {
			getSubTenantUsers(tenantRepo.findByTenant(admin.getTenant()).getId());
		}
		securityService.enableUserFilter(admin.getTenant().getId());
		List<Users> result = usersRepo.findAll();
		securityService.disableFilter();
		List<Users> result2 = new ArrayList<>();
		if (tenantRepo.findByTenant(admin.getTenant()) != null) {
			result2 = getSubTenantUsers(tenantRepo.findByTenant(admin.getTenant()).getId());
		}
		result.addAll(result2);
		return result;
	}

	@Override
	public void createDepartment(String parentId, String childName, String tenant) {
		String departmentId = generator.departmentsIdGeneration();
		System.out.println("Success");
		Departments department = new Departments();
		department.setId(departmentId);
		department.setName(childName);
		department.setDepartment(departmentsRepo.findById(parentId).orElse(null));
		department.setTenant(departmentsRepo.findById(parentId).orElse(null).getTenant());
		departmentsRepo.save(department);
	}

	@Override
	public List<Departments> getDepartments() {
		String userId = SecurityContextHolder.getContext().getAuthentication().getName();
		Admins admin = adminsRepo.findByServiceId(userId);
		securityService.enableDepartmentsFilter(admin.getTenant().getId());
		List<Departments> result=departmentsRepo.findAll();
		securityService.disableFilter();
		return result;
	}

	@Override
	public void updateUserRole(String id, String role) {
		Users user=usersRepo.findByServiceId(id);
		securityService.enableFilter(user.getTenant().getId());
		user.setRole(rolesRepo.findByName(role));
		usersRepo.save(user);
		securityService.disableFilter();
	}

	@Override
	public List<Object> findDeptHierarchy(String id) {
		return departmentsRepo.findDeptHierarchy(id);
	}

	@Override
	public List<Users> getSubTenantUsers(String id) {
		securityService.enableUserFilter(id);
		List<Users> result = usersRepo.findAll();
		securityService.disableFilter();
		return result;
	}

}
