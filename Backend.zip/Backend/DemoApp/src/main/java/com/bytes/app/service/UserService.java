package com.bytes.app.service;

import java.util.List;

import com.bytes.app.model.Task;
import com.bytes.app.model.Users;

public interface UserService {
	
	String taskIdGeneration();

	
	//View details
	public Users viewUser();
	
	//View subordinates
	public List<Object> viewSubordinates();
	
	//Assign tasks 
	public void assignTask(Task task, String assigneeId);
	
	//View tasks
	public List<Task> viewTasks();
	
	//View subordinate tasks
	public List<Task> viewAssignedTasks();
	
	//Update Task Status
	public void updateStatus(String id,String status);


}

