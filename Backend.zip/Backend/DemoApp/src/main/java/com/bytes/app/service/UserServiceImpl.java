package com.bytes.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.bytes.app.model.Task;
import com.bytes.app.model.Users;
import com.bytes.app.repository.TaskRepo;
import com.bytes.app.repository.UsersRepo;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UsersRepo usersRepo;
	
	@Autowired
	TaskRepo taskRepo;
	
	@Autowired
	SecurityService securityService;

	@Override
	public String taskIdGeneration() {
		return null;
	}

	@Override
	public Users viewUser() {
		String userId = SecurityContextHolder.getContext().getAuthentication().getName();
		Users user=usersRepo.findByServiceId(userId);
		return user;
	}

	@Override
	public List<Object> viewSubordinates() {
		String userId = SecurityContextHolder.getContext().getAuthentication().getName();
		Users user=usersRepo.findByServiceId(userId);
		securityService.enableUserFilter(user.getTenant().getId());
		System.out.println(userId);
		List<Object> users=usersRepo.findSubordinates(user.getDepartment().getId());
		securityService.disableFilter();
		return users;
	}

	@Override
	public void assignTask(Task task, String assigneeId) {
		String userId = SecurityContextHolder.getContext().getAuthentication().getName();
		Users user=usersRepo.findByServiceId(userId);
		task.setAssignerUser(user);
		task.setAssigneeUser(usersRepo.findById(assigneeId).orElse(null));
		task.setTenant(user.getTenant());
		taskRepo.save(task);	
		}

	@Override
	public List<Task> viewTasks() {
		String userId = SecurityContextHolder.getContext().getAuthentication().getName();
		Users user=usersRepo.findByServiceId(userId);
		return taskRepo.findByAssigneeUser(user);
	}

	@Override
	public List<Task> viewAssignedTasks() {
		String userId = SecurityContextHolder.getContext().getAuthentication().getName();
		Users user = usersRepo.findByServiceId(userId);
		return taskRepo.findByAssignerUser(user);
	}

	@Override
	public void updateStatus(String id, String status) {
		Task task=taskRepo.findById(id).orElse(null);
		task.setStatus(status);
		taskRepo.save(task);			
	}

}
