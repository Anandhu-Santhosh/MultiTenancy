package com.bytes.app.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bytes.app.repository.AdminsRepo;
import com.bytes.app.repository.DepartmentsRepo;
import com.bytes.app.repository.RolesRepo;
import com.bytes.app.repository.TaskRepo;
import com.bytes.app.repository.TenantRepo;
import com.bytes.app.repository.UsersRepo;

@Component
public class IdGeneration {
	
	@Autowired
	TenantRepo tenantRepo;
	
	@Autowired
	AdminsRepo adminsRepo;
	
	@Autowired
	UsersRepo usersRepo;
	
	@Autowired
	TaskRepo taskRepo;
	
	@Autowired
	DepartmentsRepo departmentsRepo;
	
	@Autowired
	RolesRepo rolesRepo;
	
	public String tenantIdGeneration() {
		String prefix = "TENANT";
		String suffix = "0001";
		String tenantId = prefix + suffix;
		while (tenantRepo.existsById(tenantId)) {
			int currentSuffix = Integer.parseInt(suffix);
			currentSuffix++;
			suffix = String.format("%04d", currentSuffix);
			tenantId = prefix + suffix;
		}
		return tenantId;
	}
	
	public String adminIdGeneration() {
		String prefix = "ADMIN";
		String suffix = "0001";
		String tenantId = prefix + suffix;
		while (adminsRepo.existsById(tenantId)) {
			int currentSuffix = Integer.parseInt(suffix);
			currentSuffix++;
			suffix = String.format("%04d", currentSuffix);
			tenantId = prefix + suffix;
		}
		return tenantId;
	}
	public String userIdGeneration() {
		String prefix = "USER";
		String suffix = "0001";
		String tenantId = prefix + suffix;
		while (usersRepo.existsById(tenantId)) {
			int currentSuffix = Integer.parseInt(suffix);
			currentSuffix++;
			suffix = String.format("%04d", currentSuffix);
			tenantId = prefix + suffix;
		}
		return tenantId;
	}
	public String taskIdGeneration() {
		String prefix = "TASK";
		String suffix = "0001";
		String tenantId = prefix + suffix;
		while (taskRepo.existsById(tenantId)) {
			int currentSuffix = Integer.parseInt(suffix);
			currentSuffix++;
			suffix = String.format("%04d", currentSuffix);
			tenantId = prefix + suffix;
		}
		return tenantId;
	}
	public String departmentsIdGeneration() {
		String prefix = "DEPARTMENT";
		String suffix = "0001";
		String tenantId = prefix + suffix;
		System.out.println(tenantId+" Inside departmentsIdGeneration");
		boolean s=departmentsRepo.existsById(tenantId);
		System.out.println(s);
		while (departmentsRepo.existsById(tenantId)) {
			int currentSuffix = Integer.parseInt(suffix);
			currentSuffix++;
			suffix = String.format("%04d", currentSuffix);
			tenantId = prefix + suffix;
		}
		return tenantId;
	}
	
	public String rolesIdGeneration() {
		String prefix = "ROLE";
		String suffix = "0001";
		String tenantId = prefix + suffix;
		while (rolesRepo.existsById(tenantId)) {
			int currentSuffix = Integer.parseInt(suffix);
			currentSuffix++;
			suffix = String.format("%04d", currentSuffix);
			tenantId = prefix + suffix;
		}
		return tenantId;
	}

}
