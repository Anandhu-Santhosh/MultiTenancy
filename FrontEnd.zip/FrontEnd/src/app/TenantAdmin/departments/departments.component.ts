import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { KeycloakService } from 'keycloak-angular';
import { ApiService } from 'src/app/api.service';

@Component({
  selector: 'app-departments',
  templateUrl: './departments.component.html',
  styleUrls: ['./departments.component.css']
})
export class DepartmentsComponent {

  departmentName:any;
  selectedDepartment:any;
  departmentList:any;
  profile:any;
  tenant:any;
  res:any;

  async ngOnInit(){
    this.profile = (await this.keycloak.loadUserProfile());
    this.tenant=this.profile.attributes.Tenant[0];
    this.api.getDepartments().subscribe(response=>{
      this.departmentList=response;
      console.log(this.departmentList);
    })
  }

  constructor(private router:Router,private fb:FormBuilder,private api:ApiService,private keycloak:KeycloakService){}

  addDepartment(){
    this.loading();
    this.api.addDepartment(this.selectedDepartment,this.departmentName,this.tenant).subscribe(response=>{
      console.log(response);
      this.res=response;
      this.router.navigate(['tenant-dashboard']);
      alert(this.res.status);
    })
  }

  loading(){
    this.router.navigate(['loading']);
  }
}
