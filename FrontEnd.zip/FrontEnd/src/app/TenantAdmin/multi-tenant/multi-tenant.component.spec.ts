import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiTenantComponent } from './multi-tenant.component';

describe('MultiTenantComponent', () => {
  let component: MultiTenantComponent;
  let fixture: ComponentFixture<MultiTenantComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MultiTenantComponent]
    });
    fixture = TestBed.createComponent(MultiTenantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
