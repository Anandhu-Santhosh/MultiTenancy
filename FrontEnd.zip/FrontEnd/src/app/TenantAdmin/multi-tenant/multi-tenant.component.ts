import { Component } from '@angular/core';
import { ApiService } from '../../api.service';

@Component({
  selector: 'app-multi-tenant',
  templateUrl: './multi-tenant.component.html',
  styleUrls: ['./multi-tenant.component.css']
})
export class MultiTenantComponent {

  user:any;
  userList:any;
  tenant:any;
  tenantList:any;
  application={user:{id:''},responseTenant:{id:''}};

  constructor(private api:ApiService){}

  ngOnInit(){
    this.api.findTenants().subscribe(response=>{
      this.tenantList=response;
    });
    this.api.getAllUsers().subscribe(response=>{
      this.userList=response;
      console.log(response);      
    })
  }

  shareUser(){
    if(this.user!=undefined&&this.tenant!=undefined){
      console.log(this.user,"and",this.tenant);     
      const user= this.userList.filter((item: { id: any; })=>item.id==this.user)
      console.log(user[0].tenant.id);      

      if(user[0].tenant.id!=this.tenant){
        this.application.user.id=this.user;
        this.application.responseTenant.id=this.tenant;
        console.log(this.application);
        
        this.api.addApplication(this.application).subscribe(response=>{
          console.log(response);
          alert("Saved");
        })
      }else{
        alert("Select a different tenant");        
      }
    } else{
      alert('Select a user and tenant before submitting');
    }
  }
}
