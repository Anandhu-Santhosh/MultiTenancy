import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { KeycloakService } from 'keycloak-angular';
import { ApiService } from 'src/app/api.service';

@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.css']
})
export class RolesComponent {

  role:any;
  res:any;
  tenant:any;
  selectedTenant:any;
  profile: any;
  status:any;
  public async ngOnInit(){
    this.profile = (await this.keycloak.loadUserProfile());

  }

  constructor(private router:Router,private api:ApiService,private keycloak:KeycloakService){
  }


  addRole(){
    this.loading();
    console.log(this.role);
    this.tenant=this.profile.attributes.TenantName[0];
    this.api.addRole(this.role,this.tenant).subscribe(response=>{
      console.log(response);
      this.status=response;
      this.router.navigate(['tenant-dashboard']);
      alert(this.status.status);
    })
  }

  loading(){
    this.router.navigate(['loading']);
  }

}
