import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { KeycloakService } from 'keycloak-angular';
import { ApiService } from 'src/app/api.service';

@Component({
  selector: 'app-tenant-dashboard',
  templateUrl: './tenant-dashboard.component.html',
  styleUrls: ['./tenant-dashboard.component.css']
})
export class TenantDashboardComponent {
  
  userList:any;
  userCount:any;
  applications:any;
  count:any;
  viewed:boolean=false;
  filteredApplications:any;
  size:any;
  currentDate!: string;
  username: any;
  id: any;
  email!: string;

  constructor(private datePipe: DatePipe,private keycloak:KeycloakService,private api:ApiService,private router:Router){
    this.getCurrentDate();
  }

  public async ngOnInit(){
    this.username = (await this.keycloak.loadUserProfile()).firstName!;
    this.email=(await this.keycloak.loadUserProfile()).email!;
    this.id = (await this.keycloak.loadUserProfile()).id!;
    this.api.getAllUsers().subscribe(response=>{
      this.userList=response;
      this.userCount=this.userList.length;
      if(this.userCount!=0){
        this.api.sharedTable.next(response);
      }
    })
    this.api.viewApplication().subscribe(response=>{
      console.log(response);  
      this.applications=response;
      this.count=this.applications.length;    
      this.filteredApplications=this.applications.filter((item: { viewedStatus: string; })=>item.viewedStatus=="Not Viewed");
      this.size=this.filteredApplications.length;
    })
  }

  getCurrentDate() {
    const currentDate = new Date();
    const formattedDate = this.datePipe.transform(currentDate, 'fullDate');
    this.currentDate = formattedDate!;
  }

  action(item:any){
    console.log(item.user.id,item.responseTenant.id,item.responseTenant.name);
    this.api.addMultitenantUser(item.user.id,item.responseTenant.id,item.responseTenant.name).subscribe(response=>{
      console.log(response);
      
    })   
  }

  view(){
    console.log("Viewed");
    this.applications.forEach((item: { viewedStatus: string; }) => {
      item.viewedStatus="Viewed";
    });
    this.viewed=true;
    console.log(this.applications);
  }
  
}