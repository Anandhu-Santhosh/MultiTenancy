export const navbarData = [

    {
        routeLink: 'tenant-dashboard',
        icon: 'fal fa-home',
        label: 'Dashboard'
    },
    {
        routeLink: 'tenant-user',
        icon: 'fal fa-user-tie',
        label: 'User'
    },
    // {
    //     routeLink: 'tenant-department',
    //     icon: 'fal fa-building',
    //     label: 'Department'
    // },
    // {
    //     routeLink: 'tenant-role',
    //     icon: 'fal fa-user-check',
    //     label: 'Role'
    // },    
];