import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { KeycloakService } from 'keycloak-angular';
import { ApiService } from 'src/app/api.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent {

  userForm: FormGroup;
  tenant:any;
  status:any;
  res:any;
  profile: any;
  roleList:any;
  departmentList:any;
  departmentId:any;
  updatedRole:any;
  updatedDepartment:any;
  userList:any;
  roleUser:any;
  departmentUser:any;

  constructor(
    private fb: FormBuilder, private router: Router, private api:ApiService, private keycloak:KeycloakService
  ) {
    this.userForm = this.fb.group({
      userName: ['', Validators.required],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      role: ['', Validators.required],
      tenant: ['', Validators.required],
      department:['', Validators.required],
      departmentId:['', Validators.required]
    });
 
  }
  public async ngOnInit() {
    this.profile = (await this.keycloak.loadUserProfile());
    this.tenant=this.profile.attributes.TenantName[0];
    this.api.getAllRoles().subscribe(response=>{
      this.roleList=response;
      console.log(this.roleList);
      
    });
    this.api.getDepartments().subscribe(response=>{
      this.departmentList=response;
      console.log(this.departmentList);
    });
    this.api.getAllUsers().subscribe(response=>{
      this.userList=response;
      this.userList=this.userList.filter((users: { tenant: any; })=>users.tenant.name==this.tenant);
      console.log(this.tenant);
      console.log(this.userList);
      
    })
  }
 
  onSubmit() {
    const name=this.userForm.get('department')?.value;
    this.departmentId=this.departmentList.find((d: { name: any; })=>d.name==name).id;
    console.log(name,this.departmentId);
    
    this.userForm.patchValue({
      tenant:this.tenant,
      departmentId:this.departmentId
    });
    if (this.userForm.valid) { 
      this.api.createUser(this.userForm.value).subscribe(response=>{
        console.log(response); 
        this.status=response;
        alert(this.status.status);
      });
      console.log('Form submitted:', this.userForm.value);
    } else {
      alert('The form is invalid')
      console.log('Form is invalid. Please check the fields.', this.userForm.value);
    }
  }

  onCancel() {
    this.router.navigate(['tenant-dashboard']);
  }

  updateRole(){
    this.loading();
    console.log(this.roleUser,this.updatedRole);    
    this.api.updateRole(this.roleUser,this.updatedRole).subscribe(response=>{
      console.log(response);
      this.router.navigate(['tenant-user']);
      this.res=response;
      alert(this.res.status);
    })
  }

  updateDepartment(){
    this.loading();
    console.log(this.departmentUser,this.updatedDepartment);
    this.api.updateDepartment(this.departmentUser,this.updatedDepartment).subscribe(response=>{
      console.log(response);
      this.router.navigate(['tenant-user']);
      this.res=response;
      alert(this.res.status);
    })
    
  }

  loading(){
    this.router.navigate(['loading']);
  }


}
