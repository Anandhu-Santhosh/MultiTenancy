import { Component } from '@angular/core';
import { ApiService } from 'src/app/api.service';

@Component({
  selector: 'app-subordinates',
  templateUrl: './subordinates.component.html',
  styleUrls: ['./subordinates.component.css']
})
export class SubordinatesComponent {

  subordinateList:any;
  list:any;

  constructor(private api:ApiService){}

  ngOnInit(){
    this.api.viewSubordinates().subscribe(response=>{
      this.subordinateList=response;
      // for (let i = 0; i < this.subordinateList.length; i += 2) {
      //   this.list.push({
      //     name: this.subordinateList[i],
      //     role: this.subordinateList[i + 1],
      //   });
      // }
      console.log(this.subordinateList);
      
    })
  }

}
