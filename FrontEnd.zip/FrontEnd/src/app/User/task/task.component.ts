import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/api.service';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent {

  taskForm: FormGroup;
  tenants:any;
  status:any;
  taskList:any;
  taskCount!:number;
  assignedTaskCount!:number;
  completedTaskCount:any;
  subordinateList:any;
  selected:any;
  assignee:any;
  taskId!:string;
  assignedTasks:any;
  completedTask:any;
  updatedStatus: any[] = [];
  assigned:boolean=false;
  pending:boolean=false;
  completed:boolean=false;


  taskPhases = [
    { value: 'not-started', text: 'Not Started/Assigned' },
    { value: 'in-progress', text: 'In Progress' },
    { value: 'on-hold', text: 'On Hold' },
    { value: 'completed', text: 'Completed' },
    { value: 'verified-reviewed', text: 'Verified/Reviewed' },
    { value: 'approved', text: 'Approved' },
    { value: 'closed', text: 'Closed' },
    { value: 'cancelled', text: 'Cancelled' },
    { value: 'reopened', text: 'Reopened' },
  ];

  constructor( private fb: FormBuilder, private router: Router,private api:ApiService) {
    this.taskForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required],
      status: ['', Validators.required],
      endDate: ['', Validators.required],
    }); 
  }
  ngOnInit() {
    this.api.viewTasks().subscribe(response=>{
      this.taskList=response;
      this.taskCount=this.taskList.length;
      console.log(response,"task");      
    })
    this.api.viewSubordinates().subscribe(response=>{
      this.subordinateList=response;
      console.log(response,"subordinates");     
    })
    this.api.viewAssignedTasks().subscribe(response=>{
      this.assignedTasks=response;
      this.assignedTaskCount=this.assignedTasks.length;
      this.updatedStatus = new Array(this.assignedTasks.length).fill('');
      console.log(response,"assignedTasks");      
    })
    this.api.viewCompletedTasks().subscribe(response=>{
      this.completedTask=response;
      this.completedTaskCount=this.completedTask.length;
      console.log(response,"completedTask");
      
    })
  } 
 
  onSubmit() {
    if (this.taskForm.valid) {
      this.loading(); 
      const formData = {
        description: this.taskForm.get('description')!.value,
        endDate: this.taskForm.get('endDate')!.value,
        name: this.taskForm.get('name')!.value,
        status: this.taskForm.get('status')!.value,
        // Add other form controls as needed
      };
      this.api.createTasks(formData).subscribe(response=>{
        console.log(response);
        this.router.navigate(['user-task']);
      })
      console.log('Form submitted:', this.taskForm.value);
    } else {
      alert('Form is invalid. Please check the fields.');
    }
  }
  onCancel() {
    this.router.navigate(['user-dashboard']);
  }

  setTaskId(item:any){
    this.taskId=item.id;
  }

  assign(){
    if(this.assignee!=null){
      this.loading(); 
      console.log(this.assignee);
      console.log(this.taskId);
      
      this.api.assignTasks(this.taskId,this.assignee).subscribe(response=>{
        console.log(response);   
        this.router.navigate(['user-task']);   
      })
    }else{
      alert("Select a user first")
    }    
  }

  updateStatus(i:any){
    if(this.updatedStatus[i]!=''){
      this.loading(); 
      console.log(this.updatedStatus[i]);
      console.log(this.assignedTasks[i].id);
      this.api.updateTask(this.assignedTasks[i].id,this.updatedStatus[i]).subscribe(response=>{
        console.log(response);
        this.router.navigate(['user-task']);
      })  
    }else{
      alert("Select a new status");
    }      
  }

  reopenTask(i:any){
    this.loading(); 
    console.log(this.completedTask[i].id);
    this.api.updateTask(this.completedTask[i].id,"reopened").subscribe(response=>{
      console.log(response);
      this.router.navigate(['user-task']);
    })        
  }

  loading(){
    this.router.navigate(['loading']);
  }

  assignedButton(){
    this.assigned=!this.assigned;
  }
  
  pendingButton(){
    this.pending=!this.pending;
  }

  completedButton(){
    this.completed=!this.completed;
  }
}
