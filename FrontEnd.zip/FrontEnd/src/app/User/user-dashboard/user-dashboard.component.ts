import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { KeycloakService } from 'keycloak-angular';
import { ApiService } from 'src/app/api.service';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent {

  user:any;
  currentDate!: string;
  username: any;
  id: any;
  email!: string;

  constructor(private datePipe: DatePipe,private keycloak:KeycloakService,private api:ApiService,private router:Router){
    this.getCurrentDate();
  }

  public async ngOnInit(){
    this.username = (await this.keycloak.loadUserProfile()).firstName!;
    this.email=(await this.keycloak.loadUserProfile()).email!;
    this.id = (await this.keycloak.loadUserProfile()).id!;
    this.api.viewUser().subscribe(response=>{
      this.user=response;
      this.api.sharedTable.next(response);
    })
    
  }

  getCurrentDate() {
    const currentDate = new Date();
    const formattedDate = this.datePipe.transform(currentDate, 'fullDate');
    this.currentDate = formattedDate!;
  }

  loading(){
    this.router.navigate(['loading']);
  }

}
