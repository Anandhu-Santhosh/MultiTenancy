export const navbarData = [

    {
        routeLink: 'user-dashboard',
        icon: 'fal fa-home',
        label: 'Dashboard'
    },
    {
        routeLink: 'user-task',
        icon: 'fal fa-user-tie',
        label: 'User'
    },
    {
        routeLink: 'user-subordinates',
        icon: 'fal fa-users',
        label: 'Department'
    },
    // {
    //     routeLink: 'tenant-role',
    //     icon: 'fal fa-user-check',
    //     label: 'Role'
    // },    
];