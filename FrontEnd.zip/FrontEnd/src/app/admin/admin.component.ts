import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent {

  adminForm: FormGroup;
  tenants:any;
  status:any

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private api:ApiService
  ) {
    this.adminForm = this.fb.group({
      userName: ['', Validators.required],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      role: ['', Validators.required],
      tenant: ['', Validators.required],
    });
 
  }
  ngOnInit() {
   this.getTenants();
  }
 
  onSubmit() {
    this.adminForm.patchValue({
      role:this.adminForm.get('tenant')!.value+"Admin"
    })
    if (this.adminForm.valid) { 
      this.loading();
      this.api.createAdmin(this.adminForm.value).subscribe(response=>{
        console.log(response); 
        this.status=response;
        this.router.navigate(['admin']);
        alert(this.status.status);
      });
      console.log('Form submitted:', this.adminForm.value);
    } else {
      console.log('Form is invalid. Please check the fields.', this.adminForm.value);
    }
  }
  onCancel() {
    this.router.navigate(['dashboard']);
  }

  getTenants(){
    this.api.findTenants().subscribe(response=>{
      console.log(response);      
      this.tenants=response;
    })
  }

  loading(){
    this.router.navigate(['loading']);
  }
}
