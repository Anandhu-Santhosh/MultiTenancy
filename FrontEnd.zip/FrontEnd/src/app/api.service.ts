import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject, switchMap, timer } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  
  data=new Subject<any>();
  sharedTable= new Subject<any>();
  base="http://localhost:8081/api/"

  constructor(private http:HttpClient) { }

  fetchDataEveryTenSeconds(){
    return timer(0, 10000).pipe(
      switchMap(() => this.findTenants())
    );
  }

  //Master Admin
  createTenant(tenant:any){
    const url=this.base+"v1/createTenant";
    return this.http.post(url,tenant);
  }

  createAdmin(admin:any){
    const url=this.base+"v1/createAdmin";
    return this.http.post(url,admin);
  }

  createRole(role:any){
    const url=this.base+"v1/createRole/"+role;
    return this.http.get(url);
  }

  findTenants(){
    const url=this.base+"v1/findTenants";
    return this.http.get(url);
  }

  getAdmin() {
    const url=this.base+"v1/findAdmins";
    return this.http.get(url);
  }

  createMultiTenant(name:any){
    const url=this.base+"v1/createMultiTenant/"+name;
    return this.http.get(url);
  }

  getStatus(name:any) {
    const url=this.base+"v1/getStatus/"+name;
    return this.http.get(url);
  }

  addSubTenant(data:any){
    const url=this.base+"v1/addNewSubTenant";
    return this.http.post(url,data);
  }

  //Tenant Admin
  createUser(user:any){
    const url=this.base+"v2/addUser";
    return this.http.post(url,user);
  }
  
  addRole(role:String,tenant:String){
    const url=this.base+"v2/addRole/"+role+"/"+tenant;
    return this.http.get(url);
  }
  getAllRoles(){
    const url=this.base+"v2/getAllRoles";
    return this.http.get(url);
  }
  getAllUsers(){
    const url=this.base+"v2/getAllUsers";
    return this.http.get(url);
  }
  addDepartment(parent:String,child:String,tenant:String){
    const url=this.base+`v2/addDepartment/${parent}/${child}/${tenant}`;
    return this.http.get(url);
  }
  getDepartments(){
    const url=this.base+"v2/getDepartments";
    return this.http.get(url);
  }

  updateRole(id:string,role:string){
    const url=this.base+`v2/updateRole/${id}/${role}`;
    return this.http.get(url);
  }

  updateDepartment(id:string,department:string){
    const url=this.base+`v2/updateDepartment/${id}/${department}`;
    return this.http.get(url);
  }

  addMultitenantUser(userId:string,tenantId:string,tenantName:string){
    const url=this.base+`v2/addMultitenantUser/${userId}/${tenantId}/${tenantName}`;
    return this.http.get(url);
  }

  addApplication(application:any){
    const url=this.base+"v2/addApplication";
    return this.http.post(url,application);
  }

  viewApplication(){
    const url=this.base+"v2/viewApplications";
    return this.http.get(url);
  }

  //Tenant User
  viewUser(){
    const url=this.base+"v3/viewUser";
    return this.http.get(url);
  }

  createTasks(task:any){
    const url=this.base+"v3/createTask";
    return this.http.post(url,task);
  }

  assignTasks(taskId:any,assigneeId:String){
    const url=this.base+`v3/assignTask/${taskId}/${assigneeId}`;
    return this.http.get(url);
  }

  viewSubordinates(){
    const url=this.base+"v3/viewSubordinates";
    return this.http.get(url);
  }

  viewTasks(){
    const url=this.base+"v3/viewTasks";
    return this.http.get(url);
  }

  viewAssignedTasks(){
    const url=this.base+"v3/viewAssignedTasks";
    return this.http.get(url);
  }

  viewCompletedTasks(){
    const url=this.base+"v3/viewCompletedTasks";
    return this.http.get(url);
  }


  updateTask(id:any,status:any){
    const url=this.base+`v3/updateTask/${id}/${status}`;
    return this.http.get(url);
  }
  
  getSubGroups(id:any){
    const url=this.base+`v4/getSubGroups/${id}`;
    return this.http.get(url);
  }

}
