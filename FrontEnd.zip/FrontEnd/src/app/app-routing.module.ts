import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { TenantComponent } from './tenant/tenant.component';
import { AdminComponent } from './admin/admin.component';
import { RoleComponent } from './role/role.component';
import { TenantDashboardComponent } from './TenantAdmin/tenant-dashboard/tenant-dashboard.component';
import { UsersComponent } from './TenantAdmin/users/users.component';
import { DepartmentsComponent } from './TenantAdmin/departments/departments.component';
import { RolesComponent } from './TenantAdmin/roles/roles.component';
import { UserDashboardComponent } from './User/user-dashboard/user-dashboard.component';
import { TaskComponent } from './User/task/task.component';
import { SubordinatesComponent } from './User/subordinates/subordinates.component';
import { LoadingComponent } from './loading/loading.component';
import { KeycloakAuthGuard } from 'keycloak-angular';
import { AuthService } from './auth.service';
import { HomeComponent } from './home/home.component';


const routes: Routes = [
  // { path: '', redirectTo: 'home', pathMatch: 'full'},
  // { path:'**', canActivate:[AuthService]},
  { path: 'home', component: HomeComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'tenant', component: TenantComponent },
  { path: 'admin', component: AdminComponent },
  { path: 'role', component: RoleComponent },
  { path: 'tenant-dashboard', component: TenantDashboardComponent },
  { path: 'tenant-user', component: UsersComponent },
  { path: 'tenant-department', component: DepartmentsComponent },
  { path: 'tenant-role', component: RolesComponent },
  { path: 'user-dashboard', component: UserDashboardComponent },
  { path: 'user-task', component: TaskComponent },
  { path: 'user-subordinates', component: SubordinatesComponent },
  { path: 'loading', component: LoadingComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
