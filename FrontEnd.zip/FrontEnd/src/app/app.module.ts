import { APP_INITIALIZER, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BodyComponent } from './body/body.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { TenantComponent } from './tenant/tenant.component';
import { AdminComponent } from './admin/admin.component';
import { RoleComponent } from './role/role.component';
import { DatePipe } from '@angular/common';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { KeycloakService, KeycloakAngularModule } from 'keycloak-angular';
import { TenantDashboardComponent } from './TenantAdmin/tenant-dashboard/tenant-dashboard.component';
import { TenantSidenavComponent } from './TenantAdmin/tenant-sidenav/tenant-sidenav.component';
import { UsersComponent } from './TenantAdmin/users/users.component';
import { DepartmentsComponent } from './TenantAdmin/departments/departments.component';
import { RolesComponent } from './TenantAdmin/roles/roles.component';
import { TableViewComponent } from './table-view/table-view.component';
import { UserDashboardComponent } from './User/user-dashboard/user-dashboard.component';
import { UserSidenavComponent } from './User/user-sidenav/user-sidenav.component';
import { TaskComponent } from './User/task/task.component';
import { SubordinatesComponent } from './User/subordinates/subordinates.component';
import { LoadingComponent } from './loading/loading.component';
import { AuthService } from './auth.service';
import { CustomComponentsModule } from "./custom-components/custom-components.module";
import { CustomKeycloakService } from './custom-keycloak.service';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { MultiTenantComponent } from './TenantAdmin/multi-tenant/multi-tenant.component';

function initializeKeycloak(keycloak: KeycloakService, authService: AuthService) {
  // console.log(window.location.href);
  // localStorage.setItem("url", window.location.href);
  console.log(localStorage.getItem("url"));
  console.log(localStorage.getItem("keycloakLoginUrl"));
  
  

  return () => {
    return keycloak.init({
      config: {
        url: 'http://localhost:8080',
        realm: 'DemoApp',
        clientId: 'demo'
      },
      initOptions: {
        checkLoginIframe: true,
        checkLoginIframeInterval: 10,
        onLoad: 'login-required',
      },
      loadUserProfileAtStartUp: true,
    });
  }
}

@NgModule({
  declarations: [
    AppComponent,
    BodyComponent,
    SidenavComponent,
    DashboardComponent,
    TenantComponent,
    AdminComponent,
    RoleComponent,
    TenantDashboardComponent,
    TenantSidenavComponent,
    UsersComponent,
    DepartmentsComponent,
    RolesComponent,
    TableViewComponent,
    UserDashboardComponent,
    UserSidenavComponent,
    TaskComponent,
    SubordinatesComponent,
    LoadingComponent,
    HomeComponent,
    LoginComponent,
    MultiTenantComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    KeycloakAngularModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    // {
    //   provide: HTTP_INTERCEPTORS,
    //   useClass: AuthService,
    //   multi: true,
    // },
    {
      provide: APP_INITIALIZER,
      useFactory: initializeKeycloak,
      multi: true,
      deps: [KeycloakService]
    }
    //  CustomKeycloakService
    , DatePipe
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
