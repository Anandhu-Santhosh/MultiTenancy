import { state } from '@angular/animations';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router, NavigationStart, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, CanActivate } from '@angular/router';
import { KeycloakAuthGuard, KeycloakService } from 'keycloak-angular';
import keycloak from 'keycloak-js';
import Keycloak, { KeycloakConfig } from 'keycloak-js';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class AuthService implements HttpInterceptor {

  initiatorRegex: any;
  matches: any;
  constructor(private router: Router) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    this.initiatorRegex = "http://localhost:8080";
    this.matches = req.url.includes(this.initiatorRegex);
    localStorage.setItem('initiatorUrl', this.matches ? req.url : 'Doesnt match');

    if (req.url.includes('http://localhost:')) {
      const keycloakLoginUrl = req.url; // Use the current URL as the Keycloak login URL
      console.log(keycloakLoginUrl);

      localStorage.setItem('keycloakLoginUrl', keycloakLoginUrl);
    }
    return next.handle(req);

  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot, req: HttpRequest<any>): boolean {
    // Check if the current URL contains 'http://localhost:8080'
    if (req.url.includes('http://localhost:8080/realm')) {
      const keycloakLoginUrl = req.url; // Use the current URL as the Keycloak login URL
      console.log(keycloakLoginUrl);

      localStorage.setItem('keycloakLoginUrl', keycloakLoginUrl);
    }

    // Add your authentication logic here if needed

    return true; // Modify this according to your authentication logic
  }
}


// export class AuthService extends KeycloakAuthGuard implements CanActivate {

//   ngOnInit(){
//     if(this.router.url=="http://localhost:8080"){
//       localStorage.setItem("url",this.router.url);
//     }
//   }

//   constructor(
//     protected override router: Router,
//     protected keycloak: KeycloakService
//   ) {
//     super(router, keycloak);
//   }

//   isAccessAllowed(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean | UrlTree> {
//     return new Promise<boolean | UrlTree>((resolve, reject) => {
//       if (!this.authenticated) {
//         this.keycloak.login();
//         return reject(false);
//       }

//       const requiredRoles = route.data['roles'] as string[];

//       if (!requiredRoles || requiredRoles.length === 0) {
//         resolve(true);
//       } else {
//         if (this.roles.some(role => requiredRoles.includes(role))) {
//           resolve(true);
//         } else {
//           resolve(this.router.createUrlTree(['/unauthorized']));
//         }
//       }
//     });
//   }
// }