import { TestBed } from '@angular/core/testing';

import { CustomKeycloakService } from './custom-keycloak.service';

describe('CustomKeycloakService', () => {
  let service: CustomKeycloakService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustomKeycloakService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
