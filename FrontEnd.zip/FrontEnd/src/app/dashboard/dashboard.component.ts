import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { KeycloakService } from 'keycloak-angular';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {
  
  currentDate!: string;
  username: any;
  id: any;
  tenants:any;
  admins:any;
  email!: string;
  createdTenant:any;

  constructor(private datePipe: DatePipe,private keycloak:KeycloakService,private api:ApiService,private router:Router){
    this.getCurrentDate();
  }

  public async ngOnInit(){
    this.username = (await this.keycloak.loadUserProfile()).firstName!;
    this.email=(await this.keycloak.loadUserProfile()).email!;
    this.id = (await this.keycloak.loadUserProfile()).id!;
    this.getTenants();
   this.getAdmins();
    this.api.sharedTable.next(this.tenants);
  }

  getTenants(){
    this.api.findTenants().subscribe(response=>{
      console.log(response);      
      this.tenants=response
    })
  }

  getAdmins(){
    this.api.getAdmin().subscribe(response=>{
      this.admins=response;
    })
  }

  getCurrentDate() {
    const currentDate = new Date();
    const formattedDate = this.datePipe.transform(currentDate, 'fullDate');
    this.currentDate = formattedDate!;
  }
}
