import { Component } from '@angular/core';
import { loadingGifPath } from '../Files/index';

@Component({
  selector: 'app-loading',
  templateUrl: './loading.component.html',
  styleUrls: ['./loading.component.css']
})
export class LoadingComponent {

  path:any;
  
  ngOnInit(){
    console.log(loadingGifPath);
    this.path=loadingGifPath;
  }  

}
