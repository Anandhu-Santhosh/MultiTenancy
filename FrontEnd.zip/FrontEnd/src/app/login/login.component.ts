import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { KeycloakService } from 'keycloak-angular';
import { KeycloakLoginOptions } from 'keycloak-js';

interface SideNavToggle {
  screenWidth: number;
  collapsed: boolean;
}

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  masterAdmin:boolean=false;
  tenantAdmin:boolean=false;
  tenantUser:boolean=false;
  user:boolean=false;
  tenant:any;

  isSideNavCollapsed = false;
  screenWidth = 0;
  public isLoggedIn = false;
   userProfile: any;
  username!:String;
  token:any;

  keycloakLoginOptions: KeycloakLoginOptions = {
    redirectUri: 'http://localhost:4204'
  }

  constructor(protected router: Router,  private keycloak:KeycloakService) {}

  public async ngOnInit() {
    console.log("Here");

    this.isLoggedIn = await this.keycloak.isLoggedIn();
    if (this.isLoggedIn) {
      console.log("Here");

      this.userProfile = (await this.keycloak.loadUserProfile());
      console.log(this.userProfile);
      if(this.keycloak.isUserInRole("MasterAdmin")){
        console.log("MasterAdmin");       
        this.masterAdmin=true; 
        this.router.navigate(['dashboard']);
      }else{
        this.tenant=this.userProfile.attributes.TenantName[0];
        if(this.keycloak.isUserInRole(this.tenant+"Admin")){
          console.log(this.tenant);    
          this.tenantAdmin=true;    
          this.router.navigate(['tenant-dashboard']);
        }
        if(this.keycloak.isUserInRole(this.tenant+"User")){
          console.log(this.tenant); 
          this.tenantUser=true;       
          this.router.navigate(['user-dashboard']);
        }
      }
      }else{
        console.log("not logged in");
        
      }

  }

  login() {
    this.keycloak.login(this.keycloakLoginOptions);
  }

  logout() {
    this.keycloak.logout('http://localhost:4204');
  }

  onToggleSideNav(data: SideNavToggle): void{
      this.isSideNavCollapsed = data.collapsed;
      this.screenWidth = data.screenWidth;
  }
}

