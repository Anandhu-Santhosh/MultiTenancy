import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.css']
})
export class RoleComponent {

  role:any;
  res:any;
  ngOnInit(){
  }

  constructor(private api:ApiService){
  }


  addRole(){
    console.log(this.role);
    this.api.createRole(this.role).subscribe(response=>{
      this.res=response;
      alert(this.res.status);
      console.log(this.res.status);      
    })
  }

}
