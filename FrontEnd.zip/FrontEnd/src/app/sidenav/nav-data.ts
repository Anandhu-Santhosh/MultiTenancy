export const navbarData = [

    {
        routeLink: 'dashboard',
        icon: 'fal fa-home',
        label: 'Dashboard'
    },
    {
        routeLink: 'tenant',
        icon: 'fal fa-sitemap',
        label: 'Tenant'
    },
    {
        routeLink: 'admin',
        icon: 'fal fa-user-tie',
        label: 'Admin'
    },
    {
        routeLink: 'role',
        icon: 'fal fa-users',
        label: 'Role'
    },    
];

export const tenantnavbarData =[
    {
        routeLink: 'tenant-dashboard',
        icon: 'fal fa-home',
        label: 'Dashboard'
    },
    {
        routeLink: 'tenant-user',
        icon: 'fal fa-user-tie',
        label: 'User'
    },
];

export const usernavbarData =[
    {
        routeLink: 'user-dashboard',
        icon: 'fal fa-home',
        label: 'Dashboard'
    },
    {
        routeLink: 'user-task',
        icon: 'fal fa-user-tie',
        label: 'User'
    },
    {
        routeLink: 'user-subordinates',
        icon: 'fal fa-users',
        label: 'Department'
    },
];