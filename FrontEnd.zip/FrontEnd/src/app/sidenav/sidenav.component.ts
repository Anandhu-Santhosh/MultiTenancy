import { Component, EventEmitter, HostListener, OnInit, Output } from '@angular/core';
import { navbarData, tenantnavbarData, usernavbarData } from './nav-data';
import { KeycloakService } from 'keycloak-angular';

interface SideNavToggle {
  screenWidth: number;
  collapsed: boolean;
}
@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.css']
})
export class SidenavComponent implements OnInit {

  @Output() onToggleSideNav: EventEmitter<SideNavToggle> = new EventEmitter();
  collapsed = false;
  screenWidth = 0;
  navData:any;
  tenant:any;
  userProfile:any;
  heading:any;
  icon:any;

  constructor(private keycloak:KeycloakService){}

  async ngOnInit(): Promise<void> {
    this.screenWidth = window.innerWidth;
    this.userProfile = (await this.keycloak.loadUserProfile());

    if(this.keycloak.isUserInRole("MasterAdmin")){
      this.navData=navbarData;
      this.heading="Master Admin";
      this.icon="MA"
    }else{
      this.tenant=this.userProfile.attributes.TenantName[0];
      if(this.keycloak.isUserInRole(this.tenant+"Admin")){
        this.navData=tenantnavbarData;
        this.heading=this.tenant+ " Admin";
        this.icon=this.tenant.substring(0,1)+"A";
      }
      if(this.keycloak.isUserInRole(this.tenant+"User")){
        this.navData=usernavbarData;
        this.heading=this.tenant+" User";
        this.icon=this.tenant.substring(0,1)+"A";
      }
    }
  }
  toggleCollapse(): void {
    this.collapsed = !this.collapsed;    
    this.onToggleSideNav.emit({ collapsed: this.collapsed, screenWidth: this.screenWidth });
  }
  closeSidenav(): void {
    this.collapsed = false;
    this.onToggleSideNav.emit({ collapsed: this.collapsed, screenWidth: this.screenWidth });
  }

  logout() {
    this.keycloak.logout('http://localhost:4204');
  }
}
