import { Component, Input } from '@angular/core';
import { KeycloakService } from 'keycloak-angular';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-table-view',
  templateUrl: './table-view.component.html',
  styleUrls: ['./table-view.component.css']
})
export class TableViewComponent {

  @Input() sharedTable: any;
  // @Input() departmentList:any;

  dynamicColumns:string[] | undefined;
  table: any;

  constructor(private service:ApiService, private keycloakservice:KeycloakService){}
  
  async ngOnInit() {
    this.service.sharedTable.subscribe(response=>{
      console.log("Here");      
      this.table=this.transformData(response);
      console.log(this.table); 
      this.dynamicColumns= Object.keys(this.table[0]);      
    })
    // console.log(this.sharedTable);
    // this.table=this.transformData(this.sharedTable);
    // this.dynamicColumns= Object.keys(this.table[0]);      

  }

  transformData(data: any[]): any[] {
    return data.map(item => {
      const transformedItem: any = {};
      for (const key in item) {
        const transformedKey = this.toSentenceCase(key);          

        if (item.hasOwnProperty(key)) {
          const value = item[key].name || item[key].id || item[key];
          transformedItem[transformedKey] = value;
        }
      }
      return transformedItem;
    });
}
toSentenceCase(str: string): string {  
  const start=str.substring(0,1).toUpperCase();
  return start+str.substring(1);
}
}
