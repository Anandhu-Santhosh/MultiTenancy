import { Component } from '@angular/core';
import { ApiService } from '../api.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tenant',
  templateUrl: './tenant.component.html',
  styleUrls: ['./tenant.component.css']
})
export class TenantComponent {

  tenants:any;
  tenant:any;
  showNewTenantForm = false;
  newTenantName: string = '';
  subTenantName: string = '';
  selectedTenant:any;
  status:any;
  btnStatus:boolean=true;

  ngOnInit(){
    this.getTenants();
    // this.api.fetchDataEveryTenSeconds().subscribe(response=>
    //   this.tenants=response)
    this.api.getStatus("Multi-Tenant").subscribe(response=>{
      this.status=response;
      console.log(this.status);      
      if(this.status.status=="Created"){
        this.btnStatus=false;
      }
    })

  }

  constructor(private router:Router,private fb:FormBuilder,private api:ApiService){}

  getTenants(){
    this.api.findTenants().subscribe(response=>{
      console.log(response);      
      this.tenants=response
    })
  }

  addTenants(){
    this.loading();
    this.api.createTenant(this.tenant).subscribe(response=>{
      this.router.navigate(['tenant']);
      alert("Tenant Created");
    })
  }

  newTenantForm(){
    this.showNewTenantForm = !this.showNewTenantForm;
    this.newTenantName = '';
  }

  saveNewTenant() {
    this.loading();
    this.tenant={
      name:this.newTenantName,
      tenant:null
    };
    console.log(this.tenant);    
    this.api.createTenant(this.tenant).subscribe(response=>{
      this.router.navigate(['tenant']);
      alert("Tenant Created");
    })    
    console.log('Saving new tenant');
  }

  addSubTenant(){
    this.loading();
    this.tenant={
      name:this.subTenantName,
      tenant:{id:this.selectedTenant}
    };
    console.log(this.tenant);
    this.api.addSubTenant(this.tenant).subscribe(response=>{
      this.router.navigate(['tenant']);
      console.log(response);      
    })
  }

  selectTenant(data:any){
    console.log(data);
    this.selectedTenant=data;
  }

  loading(){
    this.router.navigate(['loading']);
  }

  createMultiTenant(){
    this.api.createMultiTenant("Multi-Tenant").subscribe(response=>{
      console.log(response);
      
    })
  }
}
